## TVP-VAR

install.packages('bvarsv')

library(bvarsv)
data(usmacro)
head(usmacro)
dim(usmacro)

set.seed(5813)
# Run BVAR; save parameters
fit <- bvar.sv.tvp(usmacro, p=1, tau = 40, save.parameters = TRUE, nrep = 10000)
# Impulse responses
i12_1 <- impulse.responses(fit, t=1, impulse.variable = 1, response.variable = 2)
# note 195-40-1 = 154 
i12_154 <- impulse.responses(fit, t=154, impulse.variable = 1, response.variable = 2)
i12 <- impulse.responses(fit, t=154, impulse.variable = 1, response.variable = 2)
i31 <- impulse.responses(fit, t=154, impulse.variable = 3, response.variable = 1)
i32 <- impulse.responses(fit, t=154, impulse.variable = 3, response.variable = 2)



