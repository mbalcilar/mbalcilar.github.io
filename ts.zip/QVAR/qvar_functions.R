
qvar.Phi=function (x, nstep = 10, ...) {
  nstep <- abs(as.integer(nstep))
  K=nrow(x)
  p=floor(ncol(x)/K)
  A = array(0, c(K,K,nstep))
  for (i in 1:p){
    A[,,i]=x[,((i-1)*K+1):(i*K)]
  }
  
  Phi <- array(0, dim = c(K, K, nstep + 1))
  Phi[, , 1] <- diag(K)
  Phi[, , 2] <- Phi[, , 1] %*% A[, , 1]
  if (nstep > 1) {
    for (i in 3:(nstep + 1)) {
      tmp1 <- Phi[, , 1] %*% A[, , i - 1]
      tmp2 <- matrix(0, nrow = K, ncol = K)
      idx <- (i - 2):1
      for (j in 1:(i - 2)) {
        tmp2 <- tmp2 + Phi[, , j + 1] %*% A[, , idx[j]]
      }
      Phi[, , i] <- tmp1 + tmp2
    }
  }
  return(Phi)
}

qvar.gfevd = function(model, Sigma, n.ahead=10,normalize=TRUE,standardize=TRUE) {
  A <- qvar.Phi(model, (n.ahead-1))
  Sigma <- Sigma
  gi <- array(0, dim(A))
  sigmas <- sqrt(diag(Sigma))
  for (j in 1:dim(A)[3]) {
    gi[,,j] <- t(A[,,j]%*%Sigma%*%MASS::ginv(diag(sqrt(diag(Sigma)))))
  }
  if (standardize==TRUE){
    girf=array(NA, c(dim(gi)[1],dim(gi)[2], (dim(gi)[3])))
    for (i in 1:dim(gi)[3]){
      girf[,,i]=((gi[,,i])%*%MASS::ginv(diag(diag(gi[,,1]))))
    }
    gi=girf
  }
  
  num <- apply(gi^2,1:2,sum)
  den <- c(apply(num,1,sum))
  fevd <- t(num)/den
  nfevd = fevd
  if (normalize==TRUE) {
    fevd=(fevd/apply(fevd, 1, sum))
  } else {
    fevd=(fevd)
  }
  return = list(fevd=fevd, girf=gi, nfevd=nfevd)
}



QVAR = function(y,p,quantile=rep(0.5,ncol(y))) {
  y = y
  p = p
  res1 = coef1 = NULL
  k = ncol(y)
  for (i in 1:k) {
    yx = embed(y,p+1)
    rq1 = quantreg::rq(y[-c(1:p),i]~yx[,-c(1:k)],tau=quantile[i])
    coef = coef(rq1)[-1]
    coef1 = rbind(coef1,coef) 
    res = rq1$residuals
    res1 = cbind(res1,res)
  }  
  Q = (t(res1)%*%res1)/nrow(res1)
  results = list(coef=coef1,Q=Q)
}

VS = function(CV){
  k = dim(CV)[1]
  SOFM = apply(CV,1:2,mean)*100
  VSI = (sum(rowSums(SOFM-diag(diag(SOFM))))/k)
  INC = colSums(SOFM)
  TO = colSums(SOFM-diag(diag(SOFM)))
  FROM = rowSums(SOFM-diag(diag(SOFM)))
  NET = TO-FROM
  NPSO = t(SOFM)-SOFM
  
  ALL = rbind(rbind(rbind(cbind(SOFM,FROM),c(TO,sum(TO))),c(INC,NA)),c(NET,VSI))
  
  colnames(ALL) = c(rownames(CV),"FROM")
  rownames(ALL) = c(rownames(CV),"Directional TO Others","Directional Inlcuding Own","NET Directional Connectedness")
  ALL = format(round(ALL,2),nsmall=2)
  ALL[nrow(ALL)-1,ncol(ALL)] = "TCI"
  return = list(SOFM=SOFM,VSI=VSI,TO=TO,FROM=FROM,NET=NET,ALL=ALL,NPSO=INC)  
}
