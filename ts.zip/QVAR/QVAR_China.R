rm(list=ls())

source('qvar_functions.R')

DATA0 = read.csv("China.csv")
head(DATA0)
#        DATE       CPI         IP   LR     BRENT      EPU    USEPU    EUEPU
#1 1998-01-15 -5.432956 -8.0193822 8.64 -33.44343 4.352930 4.681703 4.325309
#2 1998-02-15 -5.548869 -0.8185585 8.64 -34.41302 4.591931 4.616599 4.276795
#3 1998-03-15 -3.224510 -4.0454955 7.92 -21.82265 4.173174 4.423020 4.685883
#4 1998-04-15 -3.450318 -4.2909367 7.92 -23.14902 2.967321 4.310226 4.461268
#5 1998-05-15 -3.766550 -3.5474388 7.92 -24.56324 3.732997 4.383615 4.609599
#6 1998-06-15 -4.070041 -3.8186458 7.92 -35.50020 4.223889 4.393062 4.380563

## reorder columns
DATA = DATA0[,c("DATE", "USEPU", "EUEPU", "EPU", "BRENT", "IP", "CPI", "LR")]
head(DATA)
#        DATE    USEPU    EUEPU      EPU     BRENT         IP       CPI   LR
#1 1998-01-15 4.681703 4.325309 4.352930 -33.44343 -8.0193822 -5.432956 8.64
#2 1998-02-15 4.616599 4.276795 4.591931 -34.41302 -0.8185585 -5.548869 8.64
#3 1998-03-15 4.423020 4.685883 4.173174 -21.82265 -4.0454955 -3.224510 7.92
#4 1998-04-15 4.310226 4.461268 2.967321 -23.14902 -4.2909367 -3.450318 7.92
#5 1998-05-15 4.383615 4.609599 3.732997 -24.56324 -3.5474388 -3.766550 7.92
#6 1998-06-15 4.393062 4.380563 4.223889 -35.50020 -3.8186458 -4.070041 7.92

DATE = as.Date(as.character(DATA[,1]))
Y = DATA[,-1]
k = ncol(Y)

library(vars)
var_orders <- VARselect(Y,8)
var_orders$selection
#AIC(n)  HQ(n)  SC(n) FPE(n) 
#     1      1      1      1 


### STATIC CONNECTEDNESS MEASURES
nlag = 1   # VAR(4)
nfore = 12 # 10-step ahead forecast

# set quantiles
#quantile = rep(0.5,k)

# Scenario 1
quantile = c(0.95, 0.95, 0.95, 0.50, 0.50, 0.50, 0.50)

var_full = QVAR(as.matrix(Y), p=nlag, quantile=quantile)

qvar_anlaysis <- qvar.gfevd(var_full$coef, Sigma=var_full$Q, n.ahead=nfore)

GIRF <- qvar_anlaysis$girf
i61 <- GIRF[6,1,1:12]
plot(i61,typ='l')

GFEVD = qvar.gfevd(var_full$coef, Sigma=var_full$Q, n.ahead=nfore)$fevd
rownames(CV_full)=colnames(CV_full)=colnames(Y)
TABLE2 = VS(CV_full)
TABLE2

