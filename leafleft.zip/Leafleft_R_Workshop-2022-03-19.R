#-------------------------------------------------------------------------------
#
# Interactive maps with leaflet in R
# Mehmet Balcilar
#
# Date: 03/19/2024
# Contact: mbalcilar@newhaven.edu
#
#-------------------------------------------------------------------------------

#### Dynamic maps with leaflet ----

# Leaflet was created 11 years ago by Volodymyr Agafonkin, a Ukrainian citizen
# living in Kyiv.
# Reference: https://leafletjs.com 

# The leaflet package allows creating dynamic and interactive maps using the
# Leaflet JavaScript library. The main advantage of using leaflet is its
# flexibility and that using leaflet in R is really easy.

#### Layers, Tiles,and Views ----

# leaflet function and then add new layers with the pipe operator (%>%). 
# With addTiles you will add the default base map
# With setView you will be able to set a center point and a zoom level.

# latitude: north–south position of a point on the surface of the Earth.
# Ranges from −90° at the south pole to 90° at the north pole, with 0° at the
# Equator.

# longitude:  east–west position of a point on the surface of the Earth,  
# An angular measurement with 0° at the Prime Meridian, ranging from −180°
# westward to +180° eastward

# Use Google maps to find lng and lat of a point
# https://www.google.com/maps/@41.2916909,-72.9613517,53m/data=!3m1!1e3?hl=en-US&entry=ttu
# Maxcy main entrance in the center

library(leaflet)

leaflet() %>%
  addTiles() %>%
  setView(lng = -72.9614, lat = 41.2917, zoom = 5) # Maxcy: (lng = -72.9614, lat = 41.2917)

# Zoom in to see Maxcy building on the center  (roof centered)
leaflet() %>%
  addTiles() %>%
  setView(lng = -72.9615, lat = 41.2912, zoom = 19) # Maxcy: (lng = -72.9614, lat = 41.2912)


#### Provider Tiles ----

library(leaflet.providers)
str(providers_default(), max.level = 2)
names(providers_loaded()$providers)

# Zoom in to see Maxcy building on the center  (roof centered)
leaflet() %>%
  addProviderTiles("Esri.WorldStreetMap")  %>%
  setView(lng = -72.9453, lat = 41.2704, zoom = 13) # West Haven

leaflet() %>%
  addProviderTiles("Esri.WorldImagery")  %>%
  setView(lng = -72.9453, lat = 41.2704, zoom = 13) # West Haven


#### Markers ----

# It is possible to add different types of markers to the maps. The most common
# functions are addMarkers, which will add icon markers (and accepts custom
# markers) and addCircleMarkers, which will add circular markers that can be
# customized.

leaflet() %>%
  addTiles() %>%
  setView(lng = -72.9615, lat = 41.2912, zoom = 16) %>% 
  addMarkers(lng = -72.9615, lat = 41.2912) # Maxcy: (lng = -72.9614, lat = 41.2917)


#### Multiple markers ----

# markers from a data frame

ct_cities <- readr::read_csv(file = "data/ct_city_data.csv")
head(ct_cities)

leaflet(ct_cities) %>%
  addTiles() %>%
  setView(lng = -72.9453, lat = 41.2704, zoom = 11) %>%   # West Haven
  addMarkers()

# alternatively
leaflet(ct_cities) %>%
  addTiles() %>%
  setView(lng = -72.9453, lat = 41.2704, zoom = 11) %>%   # West Haven
  addMarkers(lng = ~lng, lat = ~lat)  # notice ~

#### Icons ----
n <- nrow(ct_cities)
icons_list <- icons(
  iconUrl = ifelse(ct_cities$City == "West Haven", 
                   'data/red.png',
                   ifelse(ct_cities$City != "West Haven", 
                          'data/marker.png', NA)),
  iconWidth = c(40, 120, rep(40,n-2)), 
  iconHeight = c(40, 120, rep(40,n-2))
)

leaflet(ct_cities) %>%
  addTiles() %>%
  setView(lng = -72.9453, lat = 41.2704, zoom = 12) %>%   # West Haven
  addMarkers(lng = ~lng, lat = ~lat, icon = icons_list)


#### Circle markers ----

# Circle markers can be drawn with addCircleMarkers. You can customize its color
# with color. You can also set the radius of the markers with radius, measured
# in pixels.

leaflet(ct_cities) %>%
  addTiles() %>%
  setView(lng = -72.9453, lat = 41.2704, zoom = 12) %>%   # West Haven
  addCircleMarkers(lng = ~lng, lat = ~lat, 
                   color = "purple", opacity = 0.40, radius = 15)


#### Polygons and polylines ----

# You can overlay polygons or spatial polygons to the maps from a shapefile or
# geojson. You will need to import your data with sf, rgdal or a similar
# package. We will use sf in our examples. In order to add the polygons you will
# need to input the data to the addPolygons function.
  
# Export UNH area from hers as OSM file
# https://www.openstreetmap.org/export#map=18/41.29054/-72.96262
# Convert OSM to GeoJson here
# https://mygeodata.cloud/converter/osm-to-geojson
# Note: Leave only the layer you want in the list of layers


# sf: Support for simple features, a standardized way to encode spatial vector
# data
library(sf)

# Read a Geojson or shapefile
data_buildings <- read_sf("data/UNH_buildings.geojson")
data_amenity <- read_sf("data/UNH_amenity.geojson")
data_landcover <- read_sf("data/UNH_landcover.geojson")

# Transform to leaflet projection if needed
data_buildings <- st_transform(data_buildings, crs = '+proj=longlat +datum=WGS84')
data_amenity <- st_transform(data_amenity, crs = '+proj=longlat +datum=WGS84')
data_landcover <- st_transform(data_landcover, crs = '+proj=longlat +datum=WGS84')

# show buildings as polygons
leaflet() %>%
  addTiles() %>%
  setView(lng = -72.9615, lat = 41.2912, zoom = 16) %>%
  addPolygons(data = data_buildings, color = "blue", stroke = 1, opacity = 0.8) 

# add more polygons
leaflet() %>%
  addTiles() %>%
  setView(lng = -72.9615, lat = 41.2912, zoom = 16) %>%
  addPolygons(data = data_landcover, color = "green", stroke = 1, opacity = 0.6) %>% 
  addPolygons(data = data_buildings, color = "blue", stroke = 1, opacity = 0.8)
  

#### Circles ----

# Circles can be added with the addCircles function. These circles are very
# similar to circle markers but the radius argument sets the radius in meters
# instead of pixels and can be used for instance, for creating influence areas.

# select lng and lat for West Haven and Orange

library(dplyr)

circles <- ct_cities %>% 
  filter(City == "West Haven" | City == "Orange") %>% 
  select(lng,lat)

leaflet() %>%
  addTiles() %>%
  setView(lng = -72.9615, lat = 41.2912, zoom = 12) %>%
  addCircleMarkers(data = circles, color = "red") %>%
  addCircles(data = circles, radius = 2000) 


#### Rectangles ----

# Instead of circles you can add rectangles with addRectangles but you will need
# to input the coordinates for the south-west (lng1 and lat1) and north-east
# (lng2 and lat2) corners of the rectangle to be drawn.

leaflet() %>%
  addTiles() %>%
  setView(lng = -72.9615, lat = 41.2912, zoom = 12) %>%
  addRectangles(lng1 = -72.98, lat1 = 41.28,
                lng2 = -72.92, lat2 = 41.26) 


#### Colors ----

# The colors of the circles, rectangles, polygons and other elements can be
# customized with color and its transparency with opacity. Some elements such as
# circles include the fillColor and fillOpacity arguments that will change the
# fill color while the other arguments would be used to customize the border
# color, as in the example below.

leaflet() %>%
  addTiles() %>%
  setView(lng = -72.9615, lat = 41.2912, zoom = 12) %>%
  addCircleMarkers(data = circles, color = "red") %>%
  addCircles(data = circles, radius = 2000,
             color = "blue",  opacity = 1,
             fillColor = "red", fillOpacity = 0.20) 


#### Choropleths: Displaying statistics

# Continuous palette
pal1 <- colorNumeric(palette = "viridis", domain = ct_cities$pop)

# Discrete palette
pal2 <- colorFactor("viridis", levels = ct_cities$pop)

leaflet(ct_cities) %>%
  #addTiles() %>%
  addProviderTiles(providers$CartoDB.Positron) %>% 
  setView(lng = -72.9453, lat = 41.2704, zoom = 12) %>%   # West Haven
  addCircleMarkers(lng = ~lng, lat = ~lat, 
                   color = ~pal2(ct_cities$pop), opacity = 1, weight = 4,
                   radius = sqrt(ct_cities$pop)/10) %>% 
  addLegend(position = "bottomright",
            pal = pal2, values = ~pop,
            title = "Population",
            opacity = 1)


#### Pop ups

library(htmltools)

cityLabels <- sprintf('<b>%s</b><br/>Population: %g ',
                      ct_cities$City,ct_cities$pop) %>%
  lapply(function(x) HTML(x))


map1 <- leaflet(ct_cities) %>%
  #addTiles() %>%
  addProviderTiles(providers$CartoDB.Positron) %>% 
  setView(lng = -72.9453, lat = 41.2704, zoom = 12) %>%   # West Haven
  addCircleMarkers(lng = ~lng, lat = ~lat, 
                   color = ~pal2(ct_cities$pop), opacity = 1, weight = 4,
                   radius = sqrt(ct_cities$pop)/10,
                   popup = ~cityLabels) %>% 
  addLegend(position = "bottomright",
            pal = pal2, values = ~pop,
            title = "Population",
            opacity = 1)

map1

#### Save as HTML  ----

library(htmltools)
save_html(map1, file = paste0(getwd(), '/choropleth.html'))

# or

#library(htmlwidgets)
#saveWidget(map1, file = paste0(getwd(), '/choropleth.html'))
